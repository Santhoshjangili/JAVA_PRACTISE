package Shape;
public class Square
{
   protected void draw()
    {
        System.out.println("Square");
    }
}