package Shape;
public class Circle
{
   public void draw()
    {
        System.out.println("Circle");
    }
}