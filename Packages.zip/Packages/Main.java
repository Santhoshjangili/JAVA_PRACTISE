import Shape.*;
class Main extends Square
{
    public static void main(String args[])
    {
        Main c=new Main();
        c.draw();   
        c.draw();
    }
}